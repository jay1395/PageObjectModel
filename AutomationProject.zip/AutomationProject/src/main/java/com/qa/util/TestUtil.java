package com.qa.util;

public class TestUtil {
	public static long Page_load_wait = 30;
public static long IMPLICIT_wait = 50;
}
